Harness 回归用例模板
=====================

给 Agent / RAG 系统做 CI 回归的最小可用骨架：12 条用例 + 一个 mock 工具服务。
设计原则（和站内《Agent 评测别玄学》一致）：

  1. 能算出来的指标不交给模型判断 —— 前 8 条全是确定性断言；
  2. 工具调用必须可断言 —— mock server 记录调用轨迹，方便比对 tool_correctness；
  3. 失败要能定位 —— 每条用例带 expect 明细与 references 命中要求。

文件
----
  cases.json              12 条用例（检索层 / 生成层 / 行为层）
  mock_tool_server.py     FastAPI mock，暴露 /search 与 /refund/check
  run_regression.py       跑用例、算指标、输出 report.json
  README.md               本文件

跑起来
------
  pip install fastapi uvicorn httpx
  uvicorn mock_tool_server:app --port 8100
  python run_regression.py --base http://127.0.0.1:8100
  # 期望输出：report.json + 控制台 pass_rate

接 CI
-----
  run_regression.py 退出码：pass_rate < 阈值时返回 1，可直接当门禁。
  建议阈值：确定性用例 100%，LLM-as-a-Judge 用例 >= 0.85。
