"""mock_tool_server.py — Agent 回归用的最小 mock 工具服务。

暴露两个只读工具，任何写操作一律 404（工具越权要返回 404 而不是 500）：
  GET /search?q=...        返回命中片段（带 chunk_id，方便断言溯源）
  GET /refund/check?order_id=...   返回该订单的售后资格

跑起来：
  uvicorn mock_tool_server:app --port 8100
"""

from __future__ import annotations

from fastapi import FastAPI, Query

app = FastAPI(title="Harness regression mock", version="2026.07")

CHUNKS = [
    {"chunk_id": "chunk-12", "doc_id": "doc-refund-policy-3.2", "text": "七天无理由与十五天包退不叠加，以商品页标注的售后类型为准。"},
    {"chunk_id": "chunk-08", "doc_id": "doc-shipping-sla-2.2", "text": "预售商品按商品页标注时间发货，不适用 48 小时规则。"},
    {"chunk_id": "chunk-03", "doc_id": "doc-shipping-sla-2.1", "text": "常规商品 48 小时内发货。"},
    {"chunk_id": "chunk-15", "doc_id": "doc-membership-2.3", "text": "100 积分抵 1 元，单笔最高抵扣订单金额 10%。"},
    {"chunk_id": "chunk-19", "doc_id": "doc-coupon-2.5", "text": "过期优惠券不支持恢复。"},
    {"chunk_id": "chunk-05", "doc_id": "doc-refund-policy-4.1", "text": "定制商品不属于七天无理由范围，质量问题除外。"},
    {"chunk_id": "chunk-09", "doc_id": "doc-sku-8842-specs-3", "text": "标称 IPX4，防溅水，不支持浸水。"},
    {"chunk_id": "chunk-01", "doc_id": "doc-price-guard-1.1", "text": "下单 7 天内降价可申请一键价保。"},
]

ORDERS = {
    "8842": {"order_id": "8842", "price_guard": True, "days_since_paid": 3, "customized": False},
    "1024": {"order_id": "1024", "price_guard": False, "days_since_paid": 21, "customized": True},
}


@app.get("/search")
def search(q: str = Query(..., min_length=1), top_k: int = Query(5, ge=1, le=20)):
    """最朴素的字面召回，够用来跑检索层断言；换成真向量库时接口不变。"""
    scored = []
    for c in CHUNKS:
        hit = sum(1 for token in q if token in c["text"])
        if hit:
            scored.append((hit, c))
    scored.sort(key=lambda x: -x[0])
    return {"query": q, "hits": [c for _, c in scored[:top_k]]}


@app.get("/refund/check")
def refund_check(order_id: str = Query(...)):
    order = ORDERS.get(order_id)
    if not order:
        return {"order_id": order_id, "price_guard": False, "reason": "订单不存在或无权限"}
    return {**order, "reason": "7 天内降价可申请价保" if order["price_guard"] else "超出价保窗口"}


# 任何写操作都当作越权：404 而不是 500，避免 Agent 从状态码里学到「重试可能成功」
@app.api_route("/{path:path}", methods=["POST", "PUT", "PATCH", "DELETE"])
async def deny(path: str):
    return {"error": "not_found", "path": path, "hint": "该工具集只读"}
