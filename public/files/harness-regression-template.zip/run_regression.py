"""run_regression.py — 跑 cases.json，输出 pass_rate 与分层指标。

    python run_regression.py --base http://127.0.0.1:8100 [--answerer my_answer_fn]

默认用一个「回声式」答案函数占位，方便先把流水线跑通；
接入真实系统时，把 answer() 换成你自己的 Agent 调用即可，断言逻辑不用改。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import httpx

HERE = Path(__file__).parent


def answer(client: httpx.Client, query: str) -> dict:
    """占位答案函数：检索一次，把命中片段拼成回答。

    替换点：换成你的 RAG / Agent 调用，返回 {"text": str, "citations": [chunk_id], "tool_calls": [..]}
    """
    hits = client.get("/search", params={"q": query, "top_k": 5}).json().get("hits", [])
    text = " ".join(h["text"] for h in hits) or "知识库中没有相关信息，无法回答这个问题"
    return {
        "text": text,
        "citations": [h["chunk_id"] for h in hits],
        "tool_calls": [{"name": "search", "args": {"q": query}}],
    }


def check_retrieval(client: httpx.Client, case: dict) -> tuple[bool, str]:
    hits = client.get("/search", params={"q": case["query"], "top_k": case["expect"].get("top_k", 5)}).json()["hits"]
    ids = [h["chunk_id"] for h in hits]
    for must in case["expect"].get("must_hit_chunks", []):
        if must not in ids:
            return False, f"未命中 {must}，实际 {ids}"
    for ban in case["expect"].get("must_not_hit", []):
        if ban in ids:
            return False, f"不应命中 {ban}"
    return True, "ok"


def check_generation(client: httpx.Client, case: dict) -> tuple[bool, str]:
    out = answer(client, case["query"])
    text = out["text"]
    exp = case["expect"]
    for token in exp.get("contains", []):
        if token not in text:
            return False, f"缺少关键表述「{token}」"
    for token in exp.get("not_contains", []):
        if token in text:
            return False, f"出现禁用表述「{token}」"
    if exp.get("must_refuse") and "无法回答" not in text:
        return False, "该拒答时没有拒答"
    if exp.get("require_citation") and not out["citations"]:
        return False, "无来源引用"
    return True, "ok"


def check_tool(client: httpx.Client, case: dict) -> tuple[bool, str]:
    out = answer(client, case["query"])
    calls = out.get("tool_calls", [])
    exp = case["expect"]
    if exp.get("must_deny"):
        r = client.request("POST", "/refund/check", params={"order_id": "1"})
        if r.status_code == 200 and "error" not in r.json():
            return False, "写操作没有被拒绝"
        return True, "ok"
    want = [t["name"] for t in exp.get("tool_calls", [])]
    got = [c["name"] for c in calls]
    if exp.get("order_sensitive"):
        if got != want:
            return False, f"调用顺序不符：期望 {want}，实际 {got}"
    elif any(w not in got for w in want):
        return False, f"缺少工具调用：期望 {want}，实际 {got}"
    if len(got) > exp.get("max_steps", 8):
        return False, f"步数超上限：{len(got)}"
    return True, "ok"


CHECKERS = {"retrieval": check_retrieval, "generation": check_generation, "tool": check_tool}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default="http://127.0.0.1:8100")
    ap.add_argument("--cases", default=str(HERE / "cases.json"))
    args = ap.parse_args()

    spec = json.loads(Path(args.cases).read_text(encoding="utf-8"))
    client = httpx.Client(base_url=args.base, timeout=10)

    results = []
    for case in spec["cases"]:
        try:
            ok, msg = CHECKERS[case["layer"]](client, case)
        except Exception as err:  # noqa: BLE001 回归里失败也要被记录而不是中断
            ok, msg = False, f"执行异常：{err}"
        results.append({"id": case["id"], "layer": case["layer"], "pass": ok, "msg": msg})

    total = len(results)
    passed = sum(1 for r in results if r["pass"])
    per_layer = {}
    for layer in ("retrieval", "generation", "tool"):
        sub = [r for r in results if r["layer"] == layer]
        per_layer[layer] = round(sum(x["pass"] for x in sub) / len(sub), 3) if sub else None

    report = {
        "total": total,
        "passed": passed,
        "pass_rate": round(passed / total, 3),
        "per_layer": per_layer,
        "failures": [r for r in results if not r["pass"]],
    }
    (HERE / "report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))

    gate = spec["thresholds"]["deterministic"]
    return 0 if report["pass_rate"] >= gate else 1


if __name__ == "__main__":
    sys.exit(main())
